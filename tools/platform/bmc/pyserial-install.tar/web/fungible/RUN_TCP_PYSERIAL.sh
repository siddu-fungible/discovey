#!/bin/bash
cd /mnt/sdmmc0p1/scripts && ./f1_uartmux.sh 1

/usr/bin/python -m serial.utils.tcp_serial_redirect -P 9990 /dev/ttyS0 1000000 < /dev/null >> /tmp/fs1600_f1-0_serial.log 2>&1 &
/usr/bin/python -m serial.utils.tcp_serial_redirect -P 9991 /dev/ttyS2 1000000 < /dev/null >> /tmp/fs1600_f1-1_serial.log 2>&1 &
