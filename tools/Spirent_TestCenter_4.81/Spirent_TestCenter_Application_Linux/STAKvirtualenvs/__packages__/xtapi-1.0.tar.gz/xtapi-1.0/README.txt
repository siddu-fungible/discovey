===================================================
XTAPI Utility -- xtapi
===================================================

The xtapi module provides common py files and the xml files whick will be used by the stak commands in the ../STAKCommands/spirent/xtapi/ folder

Installation
============

**Using pip**

    Make sure python-pip is installed on you system.  If you are using virtualenv, then pip is alredy installed into environments created by vertualenv.  Run pip to install xtapi:

    ``pip install xtapi-4.52.tar.gz``

**From Source**

    The xtapi package is created by the XTAPI developer, can be used directly

Usage
=====

this package will only be used by the XTAPI developer,  and the classes and functions definded in the file will be called in the STAK commands developed by the XTAPI developer

For example usage, look in the STAK commands in the ../STAKCommands/spirent/xtapi/ folder
Requirements
============

 - Python 2.7 or greater

Development Tools
=================

Development tools are only required for doing development work and running
tests.

 - P4

Bugs and Issues
===============
