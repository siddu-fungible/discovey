import re
import sys
import os
import platform
import xml.etree.cElementTree as ET
from tapiclass import TapiParam, TapiItem

nss = {'stc': 'urn:www.spirentcom.com:XMLSchema.xsd'}
ET.register_namespace('stc', 'urn:www.spirentcom.com:XMLSchema.xsd')


class CanSaveAs:
    save = 0
    skip = 1
    save_next = 2
    save_split = 3


class MetaClass:

    def __init__(self, packageName, baseName, pluginName, name, id, canCreate):
        self.packageName = packageName
        self.baseName = baseName
        self.pluginName = pluginName
        self.name = name
        self.id = id
        self.canCreate = canCreate
        self.relationDict = {}
        self.propertyDict = {}
        self.paramDict = {}
        self.aliasDict = {}
        self.saveAsScript = ""
        self.classCondition = {}
        self.enumDict = {}
        self.keySwitchDict = {}

    def addAlias(self, alias, property, isBase=False):
        myel = ""
        for el in self.aliasDict:
            if self.aliasDict[el].isEqualProp(property):
                myel = el
                if isBase:
                    return
        if myel != "":
            self.aliasDict.pop(myel)
        # splitName = MetaClassManager.splitName(property.name)
        # if alias != splitName and re.search("-", property.name) == None:
        #    print "The param's definition in tapi.xml may be wrong:"
        #    print "\t" + self.name + "." + property.name
        self.aliasDict[alias] = property

    def getName(self):
        return self.name

    def getAliasDict(self):
        return self.aliasDict

    def getParamDict(self):
        return self.paramDict

    def getPropertyDict(self):
        return self.propertyDict

    def setProperty(self, propertyName, MetaProperty):
        self.propertyDict[propertyName.lower()] = MetaProperty

    def getEnumDict(self):
        return self.enumDict

    def isCreatable(self):
        if self.canCreate == 'false':
            return False
        return True

    def setCanCreate(self, cancreate):
        self.canCreate = cancreate

    def addMetaEnum(self, metaEnum):
        self.enumDict[metaEnum.getName()] = metaEnum

    def getId(self):
        return self.id

    def getPluginName(self):
        return self.pluginName

    def getBaseClass(self):
        return self.baseName

    def getBaseChildren(self):
        baseChildren = ""
        relationClsList = self.getRelationCls("baseChild")
        for element in relationClsList:
            dst = element.getDstClassRef().lower()
            baseChildren += dst + " "
            eBase = MetaClassManager.mapping[dst].getBaseChildren()
            if eBase != "":
                baseChildren += eBase + ""
        return baseChildren

    def getRelationParam(self):
        relationParam = ""
        for key in self.paramDict.keys():
            result = re.match(r"(.*)\-(.*)", key)
            if result is not None:
                relationParam += key + " "
        return relationParam

    def getParentClassName(self):
        parentName = ""
        relationClsList = self.getRelationCls("framework.ParentChild")
        for element in relationClsList:
            parentName += element.getSrcClassRef() + " "
        return parentName

    def getClassCondition(self):
        return self.classCondition

    def isCollectionParam(self, aliasKey):
        if aliasKey in self.aliasDict:
            if self.aliasDict[aliasKey].maxOccurs != str(1):
                if not self.isExistChildOfParents():
                    return True
        return False

    def isExistChildOfParents(self):
        relationType = "framework.ParentChild"
        if relationType in self.relationDict:
            for element in self.relationDict[relationType]:
                if (element.minOccurs != element.maxOccurs or
                        element.minOccurs != '1'):
                    return False
        return True

    def isExistChildOf(self, parent):
        srcClassRef = re.sub('[0-9]*$', '', parent)
        relationType = "framework.ParentChild"
        if relationType in self.relationDict:
            for element in self.relationDict[relationType]:
                ret = re.search(srcClassRef, element.srcClassRef, flags=re.I)
                if (element.srcClassRef.lower() == srcClassRef.lower() or
                        ret is not None):
                    if (element.minOccurs == element.maxOccurs and
                            element.minOccurs == '1'):
                        return True
        return False

    def clone(self, newname):
        other = MetaClass(self.packageName, self.baseName, self.pluginName,
                          newname, self.id, self.canCreate)
        other.relationDict = self.relationDict.copy()
        other.propertyDict = self.propertyDict.copy()
        other.enumDict = self.enumDict.copy()
        other.saveAsScript = ""
        other.paramDict = {}
        other.aliasDict = {}
        other.classCondition = {}
        return other

    def removeProp(self, prop):
        if prop in self.propertyDict:
            self.propertyDict.__delitem__(prop)

    def setRelation_basechild(self, relationCls, curCls, type='child'):
        cloneFunc = relationCls.cloneRelationBy
        mapping = MetaClassManager.mapping
        addrelation = cloneFunc(type, self.name)
        if addrelation is not None:
            self.setRelation(addrelation.getType(), addrelation)
            basechild_relations = self.getRelationCls("baseChild")
            for element in basechild_relations:
                myelem = element.getDstClassRef().lower()
                mycmp = element.getSrcClassRef().lower()
                cmp = relationCls.srcClassRef.lower()
                if myelem in MetaClassManager.mapping:
                    if (re.match(cmp, myelem, flags=re.I)
                            or re.match(cmp, mycmp, flags=re.I)):
                        dst = element.getDstClassRef()
                        addrel1 = cloneFunc("child", dst)
                        mapping[myelem].setRelation(addrel1.getType(),
                                                    addrel1)
                        addrel2 = cloneFunc("framework.ParentChild",
                                            element.getDstClassRef())
                        curCls.setRelation(addrel2.getType(), addrel2)
            basecls = self.getBaseClass().lower()

    def addbaseChildRelations(self, childCls):
        addrelation = MetaRelation("baseChildof" + self.name, "baseChild",
                                   self.name, childCls.name, 1, 1)
        self.setRelation("baseChild", addrelation)

    def setRelation(self, relationType, relationCls):
        relationClsList = []
        if relationType in self.relationDict:
            relationClsList = self.relationDict[relationType]
        if (len(relationClsList) == 0 or
                relationClsList.count(relationCls) == 0):
            isEqual = False
            for element in relationClsList:
                if element.isEqual(relationCls):
                    isEqual = True
            if isEqual is False:
                relationClsList.append(relationCls)
        self.relationDict[relationType] = relationClsList

    def copyProperties(self, other):
        for key, value in self.propertyDict.items():
            other.propertyDict[key] = value

    def copyRelations(self, other):
        mapping = MetaClassManager.mapping
        for key, value in self.relationDict.items():
            if key == "framework.ParentChild":
                for element in value:
                    other_value = element.cloneRelation(other.name)
                    other.setRelation(other_value.getType(), other_value)
                    myelem = element.srcClassRef.lower()
                    if myelem in mapping:
                        findRelation = mapping[myelem].findRelationClsByDst
                        childrelation = findRelation("child",
                                                     element.dstClassRef)
                        if childrelation is not None:
                            for child in childrelation:
                                cloneRelation = child.cloneRelation
                                other_relation = cloneRelation(other.name)
                                other_relation_t = other_relation.getType()
                                mapping[myelem].setRelation(other_relation_t,
                                                            other_relation)
            elif key != "baseChild":
                for element in value:
                    other_value = element.cloneRelationBy(element.getType(),
                                                          other.name)
                    other.setRelation(other_value.getType(), other_value)
                    if key == "child":
                        cloneFunc = element.cloneRelationBy
                        addrelation2 = cloneFunc("framework.ParentChild",
                                                 other.name)
                        dstCls = element.getDstClassRef().lower()
                        if dstCls in mapping:
                            mapping[dstCls].setRelation(addrelation2.getType(),
                                                        addrelation2)

    def getRelationCls(self, relationType):
        if relationType in self.relationDict:
            return self.relationDict[relationType]
        return {}

    def replaceRelationClsByDst(self, relationType, dstClassRef, newDstRef):
        if relationType in self.relationDict:
            for element in self.relationDict[relationType]:
                if element.dstClassRef.lower() == dstClassRef.lower():
                    element.changeRelationRef("dst", dstClassRef, newDstRef)

    def findRelationClsByDst(self, relationType, dstClassRef):
        element_list = []
        if relationType in self.relationDict:
            for element in self.relationDict[relationType]:
                if element.dstClassRef == dstClassRef:
                    element_list.append(element)
        if len(element_list) > 0:
            return element_list
        return None

    def findRelationClsBySrc(self, relationType, srcClassRef):
        element_list = []
        if relationType in self.relationDict:
            for element in self.relationDict[relationType]:
                if element.srcClassRef == srcClassRef:
                    element_list.append(element)
        if len(element_list) > 0:
            return element_list
        return None

    def addParam(self, myParam):
        myprop = myParam.getProp()
        mapping = MetaClassManager.mapping
        self.paramDict[myprop.lower()] = myParam
        property1 = None
        if myprop.lower() in self.propertyDict:
            property1 = self.propertyDict[myprop.lower()]
            alias = myParam.getAlias()
            self.addAlias(alias, self.propertyDict[myprop.lower()])
        else:
            myprop1 = re.sub("\-.*", "", myprop)
            if myprop1 in self.relationDict:
                relation1 = self.relationDict[myprop1]
                for rel_value in relation1:
                    property1 = MetaProperty(myprop.lower(),
                                             rel_value.getMaxOccurs(),
                                             rel_value.getMinOccurs(),
                                             "")
                    self.propertyDict[myprop.lower()] = property1
                    self.addAlias(myParam.getAlias(), property1)
            if myprop1 is not None:
                self.saveAsScript = "wait"
        if "baseChild" in self.relationDict:
            for element in self.relationDict["baseChild"]:
                if self.name == element.getSrcClassRef():
                    myelem = element.getDstClassRef().lower()
                    if property1 is not None:
                        myprop = myprop.lower()
                        alias = myParam.getAlias()
                        mapping[myelem].propertyDict[myprop] = property1
                        mapping[myelem].addAlias(alias, property1, True)
                        mapping[myelem].paramDict[myprop] = myParam
        if (re.match('.*\.', self.name) is not None and
                "framework.ParentChild" in self.relationDict):
            for element in self.relationDict["framework.ParentChild"]:
                if self.name == element.getSrcClassRef():
                    pelem = element.getDstClassRef().lower()
                else:
                    pelem = element.getSrcClassRef().lower()
                if (pelem in mapping and
                        re.match(pelem, self.name, flags=re.I) is not None):
                    myname = re.sub('.*\.', "", self.name)
                    mapping[pelem].replaceRelationClsByDst("child",
                                                           myname,
                                                           self.name)

    def buildup(self, tParser):
        mapping = MetaClassManager.mapping
        for key, value in self.propertyDict.items():
            if key not in self.paramDict:
                alias = MetaClassManager.splitName(value.getName())
                myParam = TapiParam(self.name + "."+key, alias)
                self.paramDict[key] = myParam
                self.addAlias(alias, value)
        for key, value in self.relationDict.items():
            if (key != "baseChild" and key != "child" and
                    key != "framework.ParentChild"):
                for element in value:
                    dstRefName = element.getDstClassRef().lower()
                    clsRef = mapping[dstRefName]
                    for pname, param in clsRef.paramDict.items():
                        myprop = re.sub("\-.*", "", param.getProp())
                        if key == myprop:
                            prop = param.getProp().lower()
                            property1 = MetaProperty(prop,
                                                     value[0].getMaxOccurs(),
                                                     value[0].getMinOccurs(),
                                                     "")
                            alias = param.getAlias()
                            clsRef.propertyDict[prop] = property1
                            clsRef.addAlias(alias, property1)

                            # check if parent.obj in the mapping, if it is,
                            # need to also update the parent.obj
                            parentAddClsRef = ''
                            relationDict = clsRef.relationDict
                            if 'framework.ParentChild' in relationDict:
                                Parent = relationDict['framework.ParentChild']
                                parent = Parent[0].getSrcClassRef().lower()
                                newClsRefIndex = parent + '.' + dstRefName
                                if newClsRefIndex in mapping:
                                    newClsRef = mapping[newClsRefIndex]
                                    newClsRef.propertyDict[prop] = property1
                                    newClsRef.addAlias(alias, property1)
                            relationDict = clsRef.relationDict
                            if "baseChild" in relationDict:
                                for basechild in relationDict["baseChild"]:
                                    srcref = basechild.getSrcClassRef()
                                    if clsRef.name == srcref:
                                        dstref = basechild.getDstClassRef()
                                        dstref = dstref.lower()
                                        pD = mapping[dstref].propertyDict
                                        aliasD = mapping[dstref].aliasDict
                                        paramD = mapping[dstref].paramDict
                                        a = param.getAlias()
                                        pD[param.getProp().lower()] = property1
                                        mapping[dstref].addAlias(a, property1)
                                        paramD[pname] = param
        for key, value in self.paramDict.items():
            result = re.match(r"(.*)\-(.*)", key)
            if result is not None:
                self.saveAsScript = "wait"
            if len(value.switchDict) > 0:
                self.keySwitchDict[value.alias] = value
        tapiClsList = tParser.getTapiClsList()
        if self.name.lower() in tapiClsList:
            clsCond = tapiClsList[self.name.lower()].getClsConditon()
            if len(clsCond) > 0:
                self.classCondition = clsCond

    def buildPrintTapiTree(self, tParser, table_dict, print_str, tapi_dict):
        clsItems = {}
        if self.canCreate == 'false':
            return print_str

        parents = self.getParentClassName()
        for p in parents.split(" "):
            if MetaClassManager.isConfigClass(self.name, p) is False:
                self.canCreate = "false"
                return print_str

        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)

        if result is None:
            self.buildup(tParser)
            print_str = self.printTable(table_dict, print_str, tapi_dict)
            for key, value in self.relationDict.items():
                if key == "child":
                    for element in value:
                        myitems = element.buildTapiRelInfo(self.name)
                        if myitems.__len__() > 0:
                            keyList = myitems.keys()
                            keyListSorted = sorted(keyList)
                            for obj in keyListSorted:
                                value = myitems[obj]
                                value.buildup(tParser)
                                print_str = value.printTable(table_dict,
                                                             print_str,
                                                             tapi_dict)
        return print_str

    def buildTapiInfo(self):
        clsItems = {}
        if self.canCreate == 'false':
            return clsItems

        parents = self.getParentClassName()
        for p in parents.split(" "):
            if MetaClassManager.isConfigClass(self.name, p) is False:
                self.canCreate = "false"
                return clsItems

        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)

        if result is None:
            if self.name in clsItems:
                print "duplicate in clsItems"
            clsItems[self.id] = self
            for key, value in self.relationDict.items():
                if key == "child":
                    for element in value:
                        myitems = element.buildTapiRelInfo(self.name)
                        if myitems.__len__() > 0:
                            merge_dict = MetaClassManager.merge_dict_recursive
                            clsItems = merge_dict(clsItems, myitems)
        return clsItems

    def canSaveAs(self, pobjDict, objDict):
        if self.canCreate == "false":
            return CanSaveAs.skip
        if self.saveAsScript == "":
            return CanSaveAs.save
        if self.saveAsScript == "wait":
            ret = CanSaveAs.save
            relationParams = self.getRelationParam()
            for prop in relationParams.split():
                if prop in objDict:
                    ret = CanSaveAs.save_next
                    pclassname = objDict['parent']
                    if not self.isExistChildOf(pclassname):
                        ret = CanSaveAs.save_split
                    break
            if len(self.classCondition) > 0:
                for key, cond in self.classCondition.items():
                    myprop = re.sub(".*\.", "", key)
                    myvalue = pobjDict[myprop]
                    if not cond.IsPass(MetaClassManager.mapping, myvalue):
                        return CanSaveAs.skip
            return ret
        return CanSaveAs.skip

    def printMetaToFile(self, f):
        print >> f, (self.name, self.baseName)
        # print (self.name, hex(self.id), self.baseName)
        for key, value in self.propertyDict.items():
            value.printMetaToFile(f)
        for key, value in self.relationDict.items():
            print >>f, "\tRelation:" + key
            for element in value:
                element.printMetaToFile(f)

    def printMeta(self):
        print (self.name, self.baseName)
        # print (self.name, hex(self.id), self.baseName)
        for key, value in self.propertyDict.items():
            value.printMeta()
        for key, value in self.relationDict.items():
            print "\tRelation:" + key
            for element in value:
                element.printMeta()

    def printTree(self):
        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)
        if result is None:
            info_str = self.name + " -baseclass " + self.baseName
            # info_str = self.name + " -id " + hex(self.id) + "
            # -baseclass " + self.baseName
            MetaClassManager.printIndent(info_str)
            info_str = "\tproperties: "
            for key, value in self.propertyDict.items():
                info_str += value.getProperty() + " "
            MetaClassManager.printIndent(info_str)
            for key, value in self.relationDict.items():
                if key == "child":
                    MetaClassManager.indent += 1
                    for element in value:
                        element.printTree(self.name)
                    MetaClassManager.indent -= 1

    def printTreeOccurs(self, maxOccurs, minOccurs):
        regexp = re.compile('base', re.IGNORECASE)
        result = regexp.search(self.name)
        if result is None:
            if minOccurs != "1" or maxOccurs != "1":
                MetaClassManager.printIndent(" + " + self.name + "[" +
                                             minOccurs + "-" + maxOccurs + "]")

    def printTable(self, table_dict, print_str, tapi_dict):
        for key, value in self.aliasDict.items():
            if key in table_dict:
                if re.search(self.name, table_dict[key]) is None:
                    print_str = re.sub(key + "\t\t\t\t" +
                                       table_dict[key] + "\t",
                                       key + "\t\t\t\t" +
                                       table_dict[key] + "," +
                                       self.name + "\t", print_str)
                    table_dict[key] = table_dict[key]+","+self.name
                    tapi_dict[key].addObj(key, self.name)
            else:
                print_str = str(print_str + key + "\t\t\t\t" + self.name +
                                "\t\t\t\t" + value.getName() +
                                "\t\t\t\t" + value.getDefaultValue() + "\n")
                table_dict[key] = self.name
                item = TapiItem(key, self.name, value.getName())
                tapi_dict[key] = item
        return print_str


class MetaEnum:
    def __init__(self, name):
        self.name = name
        self.enumDict = {}

    def getName(self):
        return self.name

    def addEnum(self, name, value):
        self.enumDict[name] = value

    def getEnumValue(self, name, value):
        return self.enumDict[name]


class MetaRelation:

    def __init__(self, name, relationType, srcClassRef,
                 dstClassRef, maxOccurs, minOccurs):
        self.relationType = relationType
        self.srcClassRef = srcClassRef
        self.dstClassRef = dstClassRef
        self.srcClassRefEx = ""
        self.dstClassRefEx = ""
        if srcClassRef.lower() in MetaClassManager.mapping:
            self.srcClassRefEx = MetaClassManager.mapping[srcClassRef.lower()]
        if dstClassRef.lower() in MetaClassManager.mapping:
            self.dstClassRefEx = MetaClassManager.mapping[dstClassRef.lower()]
        self.name = name
        self.maxOccurs = maxOccurs
        self.minOccurs = minOccurs

    def getName(self):
        return self.name

    def getMaxOccurs(self):
        return self.maxOccurs

    def getMinOccurs(self):
        return self.minOccurs

    def getType(self):
        return self.relationType

    def setType(self, newType):
        self.relationType = newType

    def getSrcClassRef(self):
        return self.srcClassRef

    def getDstClassRef(self):
        return self.dstClassRef

    def isInRelation(self, name):
        if re.search(self.srcClassRef, name, flags=re.I) is not None:
            return True
        if re.search(self.dstClassRef, name, flags=re.I) is not None:
            return True
        return False

    def processRelation(self, clsName, infoParser):
        mapping = MetaClassManager.mapping
        if (self.relationType == "framework.ParentChild" and
                self.srcClassRef == clsName):
            dstref = self.dstClassRef.lower()
            if dstref in mapping:
                addrelation = self.cloneRelation(self.dstClassRef)
                mapping[dstref].setRelation(addrelation.relationType,
                                            addrelation)
                self.relationType = "child"

    def isEqual(self, other):
        if (self.relationType == other.relationType and
                self.srcClassRef == other.srcClassRef and
                self.dstClassRef == other.dstClassRef and
                self.maxOccurs == other.maxOccurs and
                self.minOccurs == other.minOccurs):
            return True
        return False

    def cloneRelationBy(self, type, classkey):
        if self.dstClassRef == classkey:
            other = MetaRelation(type + "of" + self.srcClassRef, type,
                                 self.srcClassRef, classkey,
                                 self.maxOccurs, self.minOccurs)
        else:
            other = MetaRelation(type + "of" + classkey, type, classkey,
                                 self.dstClassRef, self.maxOccurs,
                                 self.minOccurs)
        return other

    def cloneRelation(self, dstClassRef):
        other = MetaRelation(dstClassRef, self.relationType, self.srcClassRef,
                             dstClassRef, self.maxOccurs, self.minOccurs)
        return other

    def buildTapiRelInfo(self, parent):
        if parent == self.srcClassRef:
            clsname = self.dstClassRef.lower()
            newname = parent.lower() + "." + clsname
            if newname in MetaClassManager.mapping:
                cls = MetaClassManager.mapping[newname]
            else:
                cls = MetaClassManager.mapping[clsname]
            return cls.buildTapiInfo()

    def changeRelationRef(self, type, refName, refNewName):
        if type == "dst":
            if self.dstClassRef == refName:
                self.dstClassRef = refNewName
        if type == "src":
            if self.srcClassRef == refName:
                self.srcClassRef = refNewName

    def printMetaToFile(self, f):
        mystr = str("\t\t" + (self.name) + "," + self.srcClassRef + "," +
                    self.dstClassRef)
        print >> f, mystr

    def printMeta(self):
        print str("\t\t" + (self.name) + "," + self.srcClassRef + "," +
                  self.dstClassRef)

    def printTree(self, parent):
        if parent == self.srcClassRef:
            clsname = self.dstClassRef.lower()
            cls = MetaClassManager.mapping[clsname]
            cls.printTree()
            cls.printTreeOccurs(self.maxOccurs, self.minOccurs)


class MetaProperty:

    def __init__(self, name, maxOccurs, minOccurs, value):
        self.name = name
        self.maxOccurs = maxOccurs
        self.minOccurs = minOccurs
        self.defaultValue = value

    def isEqualProp(self, other):
        if self.name == other.name:
            if self.maxOccurs == other.maxOccurs:
                if self.minOccurs == other.minOccurs:
                    if self.defaultValue == other.defaultValue:
                        return True
        return False

    def getName(self):
        return self.name

    def getDefaultValue(self):
        return self.defaultValue

    def getMaxOccurs(self):
        return self.maxOccurs

    def printMetaToFile(self, f):
        MetaClassManager.printIndentToFile(
            "\tProperty:" + (self.name) + "," + self.defaultValue, f)

    def printMeta(self):
        MetaClassManager.printIndent(
            "\tProperty:" + (self.name) + "," + self.defaultValue)

    def getProperty(self):
        if self.minOccurs == "1" and self.maxOccurs == "1":
            return "-" + (self.name) + " " + self.defaultValue
        return str("-" + (self.name) + " \"" + self.defaultValue + " [" +
                   self.minOccurs + "-" + self.maxOccurs + "]\"")


class MetaClassManager:
    mapping = {}
    skipClsList = {"framework.Result": "framework.Result",
                   "framework.Command": "framework.Command"}
    indent = 0

    @staticmethod
    def printDictToFile(f):
        keyList = MetaClassManager.mapping.keys()
        keyListSorted = sorted(keyList)
        for obj in keyListSorted:
            value = MetaClassManager.mapping[obj]
            value.printMetaToFile(f)

    @staticmethod
    def printDict():
        keyList = MetaClassManager.mapping.keys()
        keyListSorted = sorted(keyList)
        for obj in keyListSorted:
            value = MetaClassManager.mapping[obj]
            value.printMeta()

    @staticmethod
    def printIndentToFile(msg, f):
        indent_str = ""
        for i in range(0, MetaClassManager.indent):
            indent_str += "\t"
        print >> f, indent_str + msg

    @staticmethod
    def printIndent(msg):
        indent_str = ""
        for i in range(0, MetaClassManager.indent):
            indent_str += "\t"
        print indent_str + msg

    @staticmethod
    def isConfigClass(clsname, chkclsname):
        if chkclsname not in MetaClassManager.skipClsList:
            return True
        MetaClassManager.skipClsList[clsname] = clsname
        return False

    @staticmethod
    def printTapiTable(pluginName):
        print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        print "hname\t\t\t\tstcobj\t\t\t\tstcattr\t\t\t\tdefault"
        table_dict = {}
        tapi_dict = {}
        print_str = ""
        for key, value in MetaClassManager.mapping.items():
            if pluginName == value.getPluginName():
                value.printTable(table_dict, print_str, tapi_dict)

    @staticmethod
    def addMetaClass(metacls):
        mymetacls = metacls.getName().lower()
        if mymetacls in MetaClassManager.mapping:
            print "err: duplicate MetaClass:" + metacls.getName()
        else:
            MetaClassManager.mapping[mymetacls] = metacls

    @staticmethod
    def splitName(name):
        name_l = ""
        reobj = re.compile('([A-Z])')
        results = reobj.split(name)
        upper = ""
        upbk = ""
        for res in results:
            if (res == " " or res == ""):
                continue
            if (name_l == ""):
                name_l = res.lower()
                if res.isupper():
                    upbk += res
            else:
                if (res.isupper()):
                    upbk += res
                    if upper == "":
                        if len(upbk) == 1:
                            name_l = name_l + "_"
                        else:
                            name_l = name_l + res.lower()
                    else:
                        if len(upbk) == 1:
                            name_l = name_l + upper.lower()
                        else:
                            if name_l[-1] == upper.lower():
                                name_l = name_l + res.lower()
                            else:
                                name_l = name_l + upper.lower() + res.lower()
                    upper = res
                else:
                    if len(upbk) > 1:
                        index = len(name_l) - 1
                        name_l = name_l[:index] + "_" + name_l[-1]
                    else:
                        if upper != "":
                            name_l = name_l + upper.lower()
                    name_l = name_l + res
                    upper = ""
                    upbk = ""
        return name_l

    @staticmethod
    def merge_dict_recursive(a, b):
        '''recursively merges dict's. not just simple a['key'] = b['key'], if
        both a and bhave a key who's value is a dict then dict_merge is called
        on both values and the result stored in the returned dictionary.'''
        if not isinstance(b, dict):
            return b
        result = dict(a)
        if (sys.version.split(' ')[0]).split('.')[0] == '3':
            for k, v in b.items():
                if k in result and isinstance(result[k], dict):
                    tmp = MetaClassManager.merge_dict_recursive(result[k], v)
                    result[k] = tmp
                else:
                    result[k] = v
        else:
            for k, v in b.iteritems():
                if k in result and isinstance(result[k], dict):
                    tmp = MetaClassManager.merge_dict_recursive(result[k], v)
                    result[k] = tmp
                else:
                    result[k] = v
        return result


class Parser:

    def __del__(self):
        if os.path.exists('temp.xml'):
            os.remove('temp.xml')

    def read_xml(self, file):
        dom = self.Parse(file)
        return dom

    def Parse(self, fileName):
        dom = None
        try:
            if os.path.exists(fileName):
                dom = ET.parse(fileName)
            else:
                curPath = os.path.dirname(__file__)
                if platform.system().startswith('Windows'):
                    fName = os.path.join(curPath, '.\\model\\' + fileName)
                else:
                    fName = os.path.join(curPath, './/model//' + fileName)
                if os.path.exists(fName):
                    dom = ET.parse(fName)
                else:
                    stcInstallDir = os.environ['STC_INSTALL_DIR']
                    import zipfile
                    zfile = os.path.join(stcInstallDir, 'Resource.zip')
                    zf = zipfile.ZipFile(zfile, 'r')
                    fb = open('temp.xml', 'wb')
                    fb.write(zf.read('Model/' + fileName))
                    fb.close()
                    dom = ET.parse('temp.xml')
        except Exception:
            return dom
        return dom


class MetaClassParser(Parser):
    entryClassDict = {}
    retDict = {}

    def __init__(self, name=""):
        self.m_entryCls = []
        self.m_leftSrcRelation = {}
        self.m_leftDstRelation = {}

    @staticmethod
    def isInEntryClassDict(clsCategory, className):
        for cls in MetaClassParser.entryClassDict[clsCategory]:
            ret = re.match(cls.name, className, flags=re.I)
            if cls.isCreatable() and ret is not None:
                return True
        return False

    def generateMetaCls(self, cls):
        clsn = cls.get("name")
        clsb = cls.get("baseClass")
        if MetaClassManager.isConfigClass(clsn, clsb) is True:
            clsc = cls.get("canCreate")
            clsid = cls.get("id")
            curCls = MetaClass(self.packageName,
                               clsb,
                               self.pluginName,
                               clsn,
                               clsid,
                               clsc)
            MetaClassManager.addMetaClass(curCls)

            relList = cls.findall("./stc:relation", nss)
            for rel in relList:
                relt = rel.get("type")
                self.generateMetaRel(rel, curCls)

            result = re.match(r"(.*)\.(.*)", curCls.getParentClassName())
            if result is not None:
                plugin_name = result.group(1)
                if plugin_name != self.pluginName:
                    self.m_entryCls.append(curCls)

            propList = cls.findall("./stc:property", nss)
            for prop in propList:
                self.generateMetaProp(prop, curCls)

            enumList = cls.findall("./stc:enumeration", nss)
            for enum in enumList:
                self.generateMetaEnum(enum, curCls)

            classkey = clsb.lower()
            mapping = MetaClassManager.mapping
            if classkey in mapping:
                mapping[classkey].copyProperties(curCls)
                mapping[classkey].copyRelations(curCls)
                mapping[classkey].addbaseChildRelations(curCls)

            self.checkLeftRelation(clsn)

    def generateMetaRel(self, rel, curCls):
        mapping = MetaClassManager.mapping
        reli = rel.get("isInternal")
        if reli == "false":
            relt = rel.get("type")
            reld = rel.get("dstClassRef")
            rels = rel.get("srcClassRef")
            regexp = re.compile('.*\.', re.IGNORECASE)
            dstClsRef = regexp.sub("", reld)
            curRel = MetaRelation(rel.get("name"),
                                  rel.get("type"),
                                  rels,
                                  dstClsRef,
                                  rel.get("maxOccurs"),
                                  rel.get("minOccurs"))
            clsName = curCls.getName()
            red = re.search(clsName, dstClsRef, flags=re.I)
            res = re.search(clsName, rels, flags=re.I)
            if (relt == "framework.ParentChild" and red is not None):
                attrkey = rels.lower()
                if attrkey in mapping:
                    tcls = mapping[attrkey]
                    tcls.setRelation_basechild(curRel,
                                               curCls)
                else:
                    result = re.match(r"(.*)\.(.*)", rels)
                    if result is not None:
                        plugin_name = result.group(1)
                        clsnm = result.group(2).lower()
                        if clsnm in mapping:
                            func = mapping[clsnm].setRelation_basechild
                            func(curRel, curCls)
                        elif plugin_name == self.pluginName:
                            self.m_leftSrcRelation[clsnm] = curRel
                    else:
                        srcref = rels.lower()
                        self.m_leftSrcRelation[srcref] = curRel
            elif (relt == "framework.ParentChild" and res is not None):
                dstref = dstClsRef.lower()
                if dstref in mapping:
                    addrel = curRel.cloneRelation(reld)
                    mapping[dstref].setRelation(addrel.relationType,
                                                addrel)
                    curRel.relationType = "child"
                else:
                    self.m_leftDstRelation[dstref] = curRel.cloneRelation(reld)
                    curRel.relationType = "child"
            curCls.setRelation(curRel.getType(), curRel)

    def checkLeftRelation(self, clsName):
        mapping = MetaClassManager.mapping
        clsName = clsName.lower()
        if clsName in self.m_leftSrcRelation:
            myrel = self.m_leftSrcRelation.pop(clsName)
            myclass = MetaClassManager.mapping[myrel.getDstClassRef().lower()]
            mapping[clsName].setRelation_basechild(myrel, myclass)
        if clsName in self.m_leftDstRelation:
            myrel = self.m_leftDstRelation.pop(clsName)
            myclass = MetaClassManager.mapping[myrel.getSrcClassRef().lower()]
            mapping[clsName].setRelation_basechild(myrel, myclass,
                                                   myrel.relationType)

    def generateMetaProp(self, prop, curCls):
        propd = prop.get("isDeprecated")
        if propd == "false":
            propi = prop.get("isInternal")
            propr = prop.get("isReadOnly")
            if propi == "false":
                if propr == "false":
                    propn = prop.get("name")
                    propx = prop.get("maxOccurs")
                    propo = prop.get("minOccurs")
                    propf = prop.get("default")
                    property = MetaProperty(propn, propx, propo, propf)
                    curCls.setProperty(property.getName(), property)

    def generateMetaEnum(self, enum, curCls):
        myenum = MetaEnum(enum.get("name"))
        curCls.addMetaEnum(myenum)
        subEnumList = enum.findall("./stc:enum", nss)
        for subenum in subEnumList:
            myenum.addEnum(subenum.get("name"), subenum.get("value"))

    def read_xml(self, file):
        dom = Parser.read_xml(self, file)
        self.pluginName = dom.getroot().get('plugin')
        self.packageName = dom.getroot().get('package')

        clsList = dom.getroot().findall("./stc:class", nss)
        for cls in clsList:
            clsr = cls.get("isReadOnly")
            clsi = cls.get("isInternal")
            if clsr == "false" and clsi == "false":
                self.generateMetaCls(cls)

        if len(self.m_entryCls) > 0:
            clsname = self.m_entryCls[0].getName().lower()
            MetaClassParser.entryClassDict[clsname] = self.m_entryCls

    def printTree(self):
        print "=========================="
        for element in self.m_entryCls:
            element.printTree()

    def buildTapiInfo(self, tParser):
        clsItems = {}
        for element in self.m_entryCls:
            merge_dict_recursive = MetaClassManager.merge_dict_recursive
            clsItems = merge_dict_recursive(clsItems, element.buildTapiInfo())
        for key, value in clsItems.items():
            value.buildup(tParser)
        return clsItems

    def printTapiTree(self, tParser):
        print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        print "hname\t\t\t\tstcobj\t\t\t\tstcattr\t\t\t\tdefault"
        table_dict = {}
        tapi_dict = {}
        print_str = ""
        for element in self.m_entryCls:
            print_str = element.buildPrintTapiTree(tParser, table_dict,
                                                   print_str, tapi_dict)
        print print_str
        print_str += self.outputTapiXml(tapi_dict)
        return print_str

    def outputTapiXml(self, tapiDict):
        objDict = {}
        print_tapi = ""
        for el in tapiDict:
            value = tapiDict[el]
            objs = value.getStringofObjs().rstrip()
            if value.isMultiObj() is True:
                print_tapi += "<tapi:map object=\""
                print_tapi += objs
                print_tapi += "\" prefix=\"? ?\">\n\t"
                print_tapi += "<tapi:param name=\"$object$."
                print_tapi += value.attr + "\" alias=\"" + el + "\"/>\n"
                print_tapi += "</tapi:map>\n\n"
                for o in objs.split(" "):
                    if o not in objDict:
                        objDict[o] = o
            else:
                if objs not in objDict:
                    objDict[objs] = objs
        print_key = ""
        for obj in objDict:
            print_key += "<tapi:retkey name=\""
            print_key += obj.lower() + "_hnd\" object=\"" + obj + "\"/>\n"
        print print_key
        print print_tapi
        return "\r\n" + print_key + "\r\n" + print_tapi

    def printTapiInfo(self, tParser):
        clsItems = self.buildTapiInfo(tParser)
        print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        print "hname\t\t\t\tstcobj\t\t\t\tstcattr\t\t\t\tdefault"
        table_dict = {}
        tapi_dict = {}
        print_str = ""
        keyList = clsItems.keys()
        keyListSorted = sorted(keyList)
        for obj in keyListSorted:
            value = clsItems[obj]
            print_str = value.printTable(table_dict, print_str, tapi_dict)
        print print_str

    def printTapiInfoToFile(self, tParser, f):
        print_str = self.printTapiTree(tParser)
        print >> f, print_str


if __name__ == '__main__':
    parser = MetaClassParser()
    curPath = os.path.dirname(__file__)

    if len(sys.argv) > 1:
        p = MetaClassParser()
        p.read_xml("isisUt.xml")
        MetaClassManager.printDict()
        p.printTree()
    else:
        if platform.system().startswith('Windows'):
            path = '..\\..\\..\\..\\UnitTest\\'
        else:
            path = './/'

        m = MetaClassManager.splitName('LspPerMessage')
        n = MetaClassManager.splitName('LSPPerMessage')
        print m, n
        k = MetaClassManager.splitName('LSPPerMESSAGE')
        j = MetaClassManager.splitName('LspPERMessage')
        print k, j

        assert m == 'lsp_per_message'
        assert m == n
        assert m == k
        assert m == j

        import array

        # arr = ["6.xml"]
        arr = ["2.xml", "3.xml", "6.xml", "450-t.xml", "isisUt.xml"]
        p = MetaClassParser()
        myfile = file("testit.txt", 'w')
        for k, v in enumerate(arr):
            fileName = os.path.join(curPath, path + v)
            p.read_xml(fileName)
            MetaClassManager.printDictToFile(myfile)
        myfile.close()

        file_object = open('testit.txt')
        all_the_text = file_object.read()
        file_object.close()

        fileName = os.path.join(curPath, path + 'testit_expected.txt')

        file_object_cmp = open(fileName)
        all_the_text_cmp = file_object_cmp.read()
        file_object_cmp.close()

        assert all_the_text_cmp == all_the_text
    print "end"
