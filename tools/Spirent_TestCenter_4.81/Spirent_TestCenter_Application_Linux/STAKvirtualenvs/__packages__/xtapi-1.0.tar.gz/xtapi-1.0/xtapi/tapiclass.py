import re


class TapiClass:

    def __init__(self, name, disable="FALSE"):
        self.disable = disable
        self.name = name
        self.classCondition = {}

    def addClsCondition(self, clsCondition):
        self.classCondition[clsCondition.getProperty()] = clsCondition

    def getClsConditon(self):
        return self.classCondition


class TapiClassCondition:

    def __init__(self, property, operator, value, type):
        self.property = property.lower()
        self.operator = operator
        self.value = value
        self.type = type

    def getProperty(self):
        return self.property

    def getValue(self):
        return self.value

    def getOperator(self):
        return self.operator

    def IsPass(self, mappingDict, myvalue):
        result = re.match(r"(.*)\.(.*)", self.property)
        if result is not None:
            myproto = result.group(1).lower()
            myprop = result.group(2)
            enumDict = mappingDict[myproto].getEnumDict()
            result = re.match(r"(.*)\.(.*)", self.value)
            if result is not None:
                myEnum = result.group(1)
                myEnumValue = result.group(2)
                if myEnumValue == myvalue:
                    return True
        return False


class TapiInterface:

    def __init__(self, name, from_obj, to_obj):
        self.APIName = name
        self.retVal = ""
        self.from_object = from_obj
        self.to_object = to_obj

    def addRetVal(self, retval):
        self.retVal = retval

    def getAPIName(self):
        return self.APIName

    def getFromObject(self):
        return self.from_object

    def getRetDict(self):
        return self.retVal.getRetDict()


class TapiRetval:

    def __init__(self, name):
        self.name = name
        self.retDict = {}

    def getName(self):
        return self.name

    def addRetKey(self, object, retkey):
        self.retDict[object] = retkey

    def getRetDict(self):
        return self.retDict


class TapiMap:

    def __init__(self, objects, prefixes):
        self.objects = objects.split()
        self.prefixes = prefixes.split()
        for j in range(0, len(self.prefixes)):
            self.prefixes[j] += "_"
        for i in range(0, len(self.objects) - len(self.prefixes)):
            self.prefixes.append("")

    def getObjects(self):
        return self.objects

    def getPrefixes(self):
        return self.prefixes


class TapiParam:

    def __init__(self, name, alias):
        result = re.match(r"(.*)\.(.*)", name)
        if result is None:
            self.obj = name
            self.prop = ""
        else:
            self.obj = result.group(1)
            self.prop = result.group(2)
        self.alias = alias
        self.switchDict = {}
        self.input = ""
        self.output = ""

    def getObj(self):
        return self.obj

    def getProp(self):
        return self.prop

    def getAlias(self):
        return self.alias

    def getDefaultValue(self):
        return self.defaultValue

    def setObj(self, obj):
        self.obj = obj

    def setAlias(self, alias):
        self.alias = alias

    def addSwitch(self, switch):
        self.switchDict[switch.value] = switch.object


class TapiSwitch:

    def __init__(self, value, object):
        self.object = object.lower()
        self.value = value.lower()


class TapiValue:

    def __init__(self, input, output):
        self.input = input
        self.output = output


class TapiItem:

    def __init__(self, key, objs, attr):
        self.key = key
        self.objs = []
        self.objs.append(objs)
        self.attr = attr

    def addObj(self, key, obj):
        if key == self.key:
            self.objs.append(obj)

    def isMultiObj(self):
        if len(self.objs) > 1:
            return True
        else:
            return False

    def getStringofObjs(self):
        str = ""
        for obj in self.objs:
            str += obj + " "
        return str
