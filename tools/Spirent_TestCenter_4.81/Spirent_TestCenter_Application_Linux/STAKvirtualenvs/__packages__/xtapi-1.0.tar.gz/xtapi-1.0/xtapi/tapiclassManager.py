###############################################################################
import re
import xml.etree.cElementTree as ET

from metaclassManager import Parser
from metaclassManager import MetaClassParser
from metaclassManager import MetaClassManager
from tapiclass import TapiParam, TapiSwitch
from tapiclass import TapiClass
from tapiclass import TapiClassCondition
from tapiclass import TapiMap
from tapiclass import TapiInterface
from tapiclass import TapiRetval

nss = {'tapi': 'urn:www.spirentcom.com:XMLSchema.xsd'}
ET.register_namespace('tapi', 'urn:www.spirentcom.com:XMLSchema.xsd')


class TapiInfoParser(Parser):
    interfaceDict = {}

    def __init__(self, name=""):
        self.m_curMap = ""
        self.m_curParams = []
        self.m_curInterface = ""
        self.m_curRetval = ""
        self.m_curClsList = {}
        self.m_curCls = ""

    def getTapiClsList(self):
        return self.m_curClsList

    @staticmethod
    def getClassNameFrom(apiName):
        for cls, tapi in TapiInfoParser.interfaceDict.items():
            if apiName == tapi.getAPIName():
                return cls
        return None

    def dealDisableTrue(self, param, curMap=""):
        mapping = MetaClassManager.mapping
        result = re.match(r"(.*)\.(.*)", param.get("name"))
        tValue = param.findall("./tapi:value", nss)
        if result is not None:
            myproto = result.group(1).lower()
            myprop = result.group(2).lower()
            if myproto in mapping:
                mapping[myproto].removeProp(myprop)
            elif curMap != "":
                objs = curMap.getObjects()
                prefixs = curMap.getPrefixes()
                for element in objs:
                    myname = myproto.replace("$object$", element)
                    myname = myname.lower()
                    if myname in mapping:
                        mapping[myname].removeProp(myprop)

    def read_xml(self, file):
        dom = Parser.read_xml(self, file)
        self.pluginName = dom.getroot().get('plugin')
        self.packageName = dom.getroot().get('package')

        mapping = MetaClassManager.mapping
        clsList = dom.getroot().findall("./tapi:class", nss)
        for cls in clsList:
            clsd = cls.get("disable")
            clsn = cls.get("name")
            if clsd == "TRUE":
                mapping[clsn.lower()].setCanCreate("false")
            else:
                curCls = TapiClass(clsn)
                self.m_curClsList[clsn.lower()] = curCls
                condList = cls.findall("./tapi:condition", nss)
                for cond in condList:
                    cond = TapiClassCondition(cond.get("property"),
                                              cond.get("operator"),
                                              cond.get("value"),
                                              cond.get("type"))
                    curCls.addClsCondition(cond)

        itfList = dom.getroot().findall("./tapi:interface", nss)
        for itf in itfList:
            myfrom = itf.get("from_object")
            if myfrom is not None:
                myfrom = myfrom.lower()
            myto = itf.get("to_object")
            if myto is not None:
                myto = myto.lower()
            apiName = itf.get("APIName")
            curInterface = TapiInterface(apiName, myfrom, myto)
            TapiInfoParser.interfaceDict[myfrom] = curInterface

            retList = itf.findall("./tapi:retval", nss)
            for ret in retList:
                keyList = ret.findall("./tapi:retkey", nss)
                curRetval = TapiRetval(ret.get("name"))
                for key in keyList:
                    obj = key.get("object").lower()
                    name = key.get("name")
                    curRetval.addRetKey(obj, name)
                    children = mapping[obj].getBaseChildren()
                    if children != "":
                        for c in children.split(" "):
                            if c != "":
                                curRetval.addRetKey(c, name)
                curInterface.addRetVal(curRetval)

            paramList = itf.findall("./tapi:param", nss)
            for param in paramList:
                disable = param.get("disable")
                if disable is None or disable == "FALSE":
                    name = param.get("name")
                    alias = param.get("alias")
                    myproto = re.sub('\..*', "", name.lower())
                    myparam = TapiParam(name, alias)
                    if myproto in mapping:
                        mapping[myproto].addParam(myparam)
                    switchList = param.findall("./tapi:switch", nss)
                    for switch in switchList:
                        myvalue = switch.get("value")
                        myobject = switch.get("object")
                        myswitch = TapiSwitch(myvalue, myobject)
                        myparam.addSwitch(myswitch)
                else:
                    self.dealDisableTrue(param)

            mapList = itf.findall("./tapi:map", nss)
            for map in mapList:
                object = map.get("object")
                prefix = map.get("prefix")
                curMap = TapiMap(object, prefix)
                paramList = map.findall("./tapi:param", nss)
                for param in paramList:
                    disable = param.get("disable")
                    if disable is None or disable == "FALSE":
                        objs = curMap.getObjects()
                        prefixs = curMap.getPrefixes()
                        index = 0
                        pname = param.get("name")
                        palias = param.get("alias")
                        tValue = param.findall("./tapi:value", nss)
                        for element in objs:
                            myname = pname.replace("$object$", element)
                            myalias = prefixs[index] + palias
                            myparam = TapiParam(myname, myalias)
                            if len(tValue) > 0:
                                for v in tValue:
                                    myparam.input = v.get("input")
                                    myparam.output = v.get("output")
                            index += 1
                            myele = element.lower()
                            if myele in mapping:
                                mapping[myele].addParam(myparam)
                            else:
                                mye1 = re.sub('.*\.', "", myele)
                                mapping[myele] = mapping[mye1].clone(element)
                                mapping[myele].addParam(myparam)
                    else:
                        self.dealDisableTrue(param, curMap)


if __name__ == '__main__':
    import sys
    import os
    import platform
    if len(sys.argv) > 1:
        p1 = MetaClassParser()
        p1.read_xml("stcCore.processed.xml")

        p = MetaClassParser()
        p.read_xml("stcPcep.processed.450.xml")

        t = TapiInfoParser()
        t.read_xml("stcPcep.tapi.xml")

        p.printTapiInfo(t)
    else:
        if platform.system().startswith('Windows'):
            path = '..\\..\\..\\..\\UnitTest\\'
        else:
            path = './/'

        p1 = MetaClassParser()
        p1.read_xml("stcCore.processed.xml")
        p = MetaClassParser()
        p.read_xml("stcPcep.processed.xml")

        myfile = file("testtapi.txt", 'w')

        MetaClassManager.printDictToFile(myfile)

        t = TapiInfoParser()
        t.read_xml("stcPcep.tapi.xml")

        tdict = TapiInfoParser.interfaceDict['pcepprotocolconfig'].getRetDict()
        print >> myfile, tdict

        p.printTapiInfoToFile(t, myfile)
        myfile.close()

        file_object = open('testtapi.txt')
        all_the_text = file_object.read()
        file_object.close()

        curPath = os.path.dirname(__file__)
        fileName = os.path.join(curPath, path + 'testtapi_expected.txt')

        file_object_cmp = open(fileName)
        all_the_text_cmp = file_object_cmp.read()
        file_object_cmp.close()

        # assert all_the_text_cmp == all_the_text

    print "end"
